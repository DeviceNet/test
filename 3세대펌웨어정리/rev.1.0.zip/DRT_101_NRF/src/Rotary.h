#ifndef __ROTARY_H
#define __ROTARY_H

#include "util.h"


void initRotary();
uint8 rotary_GetValue();

#endif
