#ifndef __XNET_PROTOCOL_H__
#define __XNET_PROTOCOL_H__
#include "Util.h"
#include "types.h"

// --------------- XNetMessage Handler --------------- //
uint8 XNetHandler(uint8 buff[], int buff_length);
#endif

